struct buf {
  int valid;   // has data been read from disk?
  int disk;    // does disk "own" buf?
  uint dev;
  uint blockno;
  struct sleeplock lock;
  uint refcnt; //引用计数​​：refcnt++防止缓冲区被回收
  //struct buf *prev; // LRU cache list
  struct buf *next;
  uchar data[BSIZE];
  uint lastuse;       //跟踪LRU,表示这个buf缓冲区的最后使用时间戳
                      //更小的lastuse值 = 更早使用 = 更适合被淘汰
};

