// Buffer cache.
//
// The buffer cache is a linked list of buf structures holding
// cached copies of disk block contents.  Caching disk blocks
// in memory reduces the number of disk reads and also provides
// a synchronization point for disk blocks used by multiple processes.
//
// Interface:
// * To get a buffer for a particular disk block, call bread.
// * After changing buffer data, call bwrite to write it to disk.
// * When done with the buffer, call brelse.
// * Do not use the buffer after calling brelse.
// * Only one process at a time can use a buffer,
//     so do not keep them longer than necessary.


#include "types.h"
#include "param.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "riscv.h"
#include "defs.h"
#include "fs.h"
#include "buf.h"

#define NBUFMAP_BUCKET 13//桶的数量
#define BUFMAP_HASH(dev,blockno) (((dev<<27)|(blockno))%NBUFMAP_BUCKET)

//物理层面数组，LRU逻辑层面指针
struct {
  //struct spinlock lock;
  struct buf buf[NBUF];

  struct spinlock eviction_lock;
  struct buf bufmap[NBUFMAP_BUCKET];//桶
  struct spinlock bufmap_lock[NBUFMAP_BUCKET];//每个桶一个锁

  // Linked list of all buffers, through prev/next.
  // Sorted by how recently the buffer was used.
  // head.next is most recent, head.prev is least.
  //struct buf head;
}bcache;
//Cache初始化
void
binit(void)
{
  //初始化桶锁
  for(int i = 0;i<NBUFMAP_BUCKET;++i){
    initlock(&bcache.bufmap_lock[i],"bcache_bufmap");
    bcache.bufmap[i].next = 0;
  }
  for(int i=0;i<NBUF;++i){
    struct buf* b = &bcache.buf[i];
    initsleeplock(&b->lock,"buffer");
    b->lastuse = 0;
    b->refcnt = 0;

    //将所有的缓存buf加入到bufmap[0]
    b->next = bcache.bufmap[0].next;
    bcache.bufmap[0].next = b;
  }
  initlock(&bcache.eviction_lock,"bcache_eviction");;
}


// Look through buffer cache for block on device dev.
// If not found, allocate a buffer.
// In either case, return locked buffer.
static struct buf*
bget(uint dev, uint blockno)//根据设备号和块号查找Cache，如果命中，返回缓冲区，没有命中，就根据LRU替换缓冲区后返回
{
  //如果命中，返回缓冲区
  struct buf *b;
  uint key = BUFMAP_HASH(dev,blockno); 
  //获取当前的桶锁 
  acquire(&bcache.bufmap_lock[key]);


  //​​起始点​​：b = bcache.head.next→ 指向 buf[2]（最后插入的）
  // Is the block already cached?
  for(b = bcache.bufmap[key].next; b; b = b->next){
    if(b->dev == dev && b->blockno == blockno){
      b->refcnt++;
      release(&bcache.bufmap_lock[key]);
      acquiresleep(&b->lock);
      return b;
    }
  }

  release(&bcache.bufmap_lock[key]);
  //这里是时间窗口----------------------1号位置
  acquire(&bcache.eviction_lock);

  for (b = bcache.bufmap[key].next; b; b = b->next)
  {
    if (b->dev == dev && b->blockno == blockno)
    {
      acquire(&bcache.bufmap_lock[key]);
      b->refcnt++;
      release(&bcache.bufmap_lock[key]);
      release(&bcache.eviction_lock);
      acquiresleep(&b->lock);
      return b;
    }
  }

  //没有命中，就根据LRU替换缓冲区后返回
  struct buf* before_least = 0;
  uint holding_bucket = -1;
  //循环查询所有桶

  for(int i= 0;i<NBUFMAP_BUCKET;++i){
    acquire(&bcache.bufmap_lock[i]);
    int newfound = 0;
    for(b = &bcache.bufmap[i];b->next;b=b->next){
      if(b->next->refcnt==0&&(!before_least||b->next->lastuse<before_least->next->lastuse)){
        //b->next缓冲区空闲并且（尚未找到任何候选缓冲区||b->next缓冲区比候选before_least缓冲区更旧）
        before_least = b;
        newfound = 1;
      }
    }
    if(!newfound)
      release(&bcache.bufmap_lock[i]);
    else{
      if(holding_bucket!=-1){//释放之前候选缓冲区的所在桶的桶锁
        release(&bcache.bufmap_lock[holding_bucket]);
      }
      holding_bucket=i;//标记当前桶为候选缓冲区所在桶，&bcache.bufmap_lock[i]就先不释放了
    }
  }
  //before_least是空闲buf的前一个buf，我们要的空闲buf是before_least->next
  //如果没找到任何一个LRU-buf，表示没有空闲内存块了
  if(!before_least)
    panic("bget: no buffuers");
  b=before_least->next;//我们要的空闲buf

  if(holding_bucket!=key){//将找到的LRU缓冲区迁移到目标key桶
    before_least->next = b->next;
    release(&bcache.bufmap_lock[holding_bucket]);

    acquire(&bcache.bufmap_lock[key]);
    b->next = bcache.bufmap[key].next;
    bcache.bufmap[key].next = b;
  }

  b->dev = dev;
  b->blockno = blockno;
  b->refcnt = 1;
  b->valid = 0;

  release(&bcache.bufmap_lock[key]);
  release(&bcache.eviction_lock);
  acquiresleep(&b->lock);//当bget()返回时，缓冲区已被锁定
  return b;
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("bwrite");
  virtio_disk_rw(b, 1);
}

// Release a locked buffer.
// Move to the head of the most-recently-used list.
// 释放某个buf
void
brelse(struct buf *b)
{
  if(!holdingsleep(&b->lock))
    panic("brelse");

  releasesleep(&b->lock);

  uint key = BUFMAP_HASH(b->dev,b->blockno);
  acquire(&bcache.bufmap_lock[key]);
  b->refcnt--;
  if(b->refcnt == 0){
    b->lastuse = ticks;
  }
  
  release(&bcache.bufmap_lock[key]);
}

void
bpin(struct buf *b) {
  uint key =  BUFMAP_HASH(b->dev,b->blockno);

  acquire(&bcache.bufmap_lock[key]);
  b->refcnt++;
  release(&bcache.bufmap_lock[key]);
}

void
bunpin(struct buf *b) {
  uint key =  BUFMAP_HASH(b->dev,b->blockno);
  acquire(&bcache.bufmap_lock[key]);
  b->refcnt--;
  release(&bcache.bufmap_lock[key]);
}


