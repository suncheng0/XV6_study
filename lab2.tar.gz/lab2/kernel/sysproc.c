#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "sysinfo.h"

uint64
sys_exit(void)
{
  int n;
  if(argint(0, &n) < 0)
    return -1;
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  if(argaddr(0, &p) < 0)
    return -1;
  return wait(p);
}

uint64
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

uint64 
sys_trace(void)
{
  int mask;// 用于存储用户传入的跟踪掩码
  // argint(0, &mask)：读取系统调用的第0个参数（用户传入的p->trapframe->a0）到mask中
  if(argint(0,&mask)<0)
    return -1;
  // 将掩码保存到当前进程的结构体中（struct proc有syscall_trace字段）
  myproc()->syscall_trace = mask;
  return 0;
}

uint64
sys_sysinfo(void){
  struct sysinfo info;
  freebytes(&info.freemem);//get free memory
  procnum(&info.nproc);//get num of activate proc

  uint64 dstaddr;
  argaddr(0,&dstaddr);//the addr of struct sysinfo from user
  if(copyout(myproc()->pagetable,dstaddr,(char*)&info,sizeof info)<0)
    return -1;
  /*
  *int copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len);
  
    pagetable：用户页表，用于将用户虚拟地址（dstva）映射到物理地址。
    dstva：目标用户虚拟地址（即用户程序指定的存储数据的地址）。
    src：源内核地址（指向内核空间中待复制的数据）。
    len：复制的字节数。
  */
    
  return 0;
}