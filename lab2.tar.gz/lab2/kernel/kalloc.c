// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;// 自旋锁, 自旋锁保证对空闲链表的操作是原子的
  struct run *freelist;
} kmem;//kmem 内存分配器

void
kinit()//初始化物理内存分配器kmem
{
  initlock(&kmem.lock, "kmem");// 初始化自旋锁
  freerange(end, (void*)PHYSTOP);// 释放从end到PHYSTOP的物理内存, PHYSTOP：物理内存的上限
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kfree(p);
}

// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  release(&kmem.lock);
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)//from 空闲链表头部取下一个页 and 分配
{
  struct run *r;

  acquire(&kmem.lock);
  r = kmem.freelist;
  if(r)
    kmem.freelist = r->next;
  release(&kmem.lock);

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk  用 0x05 填充分配的页
  return (void*)r;
}

void freebytes(uint64* dst)//空闲内存总字节数
{
  *dst = 0;
  struct run* p = kmem.freelist;
  acquire(&kmem.lock);
  while(p)
  {
    *dst += PGSIZE;//// 每个空闲页贡献PGSIZE（4096字节）
    p = p->next;
  }
  release(&kmem.lock);

}