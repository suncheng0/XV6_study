// On-disk file system format.
// Both the kernel and user programs use this header file.


#define ROOTINO  1   // root i-number
#define BSIZE 1024  // block size


// Disk layout:
// [ boot block | super block | log | inode blocks |
//                                          free bit map | data blocks]
//
// mkfs computes the super block and builds an initial file system. The
// super block describes the disk layout:
struct superblock {
  uint magic;        // Must be FSMAGIC magic：文件系统"魔数"，用于验证文件系统类型
  uint size;         // Size of file system image (blocks)
  uint nblocks;      // Number of data blocks
  uint ninodes;      // Number of inodes.
  uint nlog;         // Number of log blocks
  uint logstart;     // Block number of first log block      位置​​：logstart到 logstart + nlog - 1
  uint inodestart;   // Block number of first inode block    位置​​：inodestart到 inodestart + ninodes - 1
  uint bmapstart;    // Block number of first free map block 空闲位图区​​
};

#define FSMAGIC 0x10203040

#define NDIRECT 11
#define NINDIRECT (BSIZE/sizeof(uint))
#define MAXFILE (NDIRECT + NINDIRECT + NINDIRECT * NINDIRECT)

// On-disk inode structure
struct dinode {
  short type;           // File type
  short major;          // Major device number (T_DEVICE only)
  short minor;          // Minor device number (T_DEVICE only)
  short nlink;          // Number of links to inode in file system
  uint size;            // Size of file (bytes)
  uint addrs[NDIRECT+2];   // Data block addresses
};

// Inodes per block.  每个磁盘块能容纳的 inode 数量 == 磁盘块大小（1024字节）/单个 inode 结构的大小(64字节)
#define IPB           (BSIZE / sizeof(struct dinode))

// Block containing inode i  计算 inode 编号 i所在的物理磁盘块号
#define IBLOCK(i, sb)     ((i) / IPB + sb.inodestart)

// Bitmap bits per block  一个磁盘块的大小是BSIZE（1024字节，即8192位）  一个位图块可以管理BPB个磁盘块
#define BPB           (BSIZE*8)

// Block of free map containing bit for block b
#define BBLOCK(b, sb) ((b)/BPB + sb.bmapstart)

// Directory is a file containing a sequence of dirent structures.
#define DIRSIZ 14

struct dirent {//目录项结构体
  ushort inum; // 该目录项对应的文件或子目录的 inode 编号​​
  char name[DIRSIZ]; // 目录项的文件名
};

