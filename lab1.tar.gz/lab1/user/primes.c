//子进程会获得父进程文件描述符表的副本。这意味着父子进
//程各自拥有独立的文件描述符（整数），但这些描述符指向相同
//的文件表项（内核内部的数据结构）

/*

    父进程和子进程各自获得p[0]和p[1]的副本
    父进程关闭p[0]（读端）不会影响子进程的p[0]
    子进程关闭p[1]（写端）不会影响父进程的p[1]

*/
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void sieve(int pleft[2])
{
    //get data from father
    int p;
    read(pleft[0],&p,sizeof(p));//pleft[0]-->p
    if(p==-1)
    {
        exit(0);
    }    
    //the first num must be prime
    printf("prime %d\n",p);
    //create a new pipe
    int pright[2];
    pipe(pright);
    if(fork()==0)//child process
    {
        close(pright[1]);
        close(pleft[0]);
        sieve(pright);
    }else{//cur process
        close(pright[0]);
        int buf;
        while(read(pleft[0],&buf,sizeof(buf))&&buf!=-1)
        {
            if(buf%p!=0){
                write(pright[1],&buf,sizeof(buf));
            }
        }
        buf = -1;
        write(pright[1],&buf,sizeof(buf));
        wait(0);
        exit(0);
    }
}

int main(int argc,char **argv)
{
    int input_pipe[2];
    pipe(input_pipe);//main-->first child process
    

    if(fork()==0)
    {
        close(input_pipe[1]);
        sieve(input_pipe);
        exit(0);
    }
    else{
        close(input_pipe[0]);
        int i;
        for(i=2;i<=35;i++)
        {
            write(input_pipe[1],&i,sizeof(i));
        }
        i=-1;
        write(input_pipe[1],&i,sizeof(i));
    }
    wait(0);//wait for child to over
    exit(0);
}

