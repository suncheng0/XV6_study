#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

void run(char* program, char** args){
    if(fork()==0){
        exec(program,args);//exec(file_path,argvs)
        exit(0);
    }
    return;
}

int main(int argc,char* argv[]){
    char buf[2048];
    char *p= buf,*last_p = buf;
    //
    char* argsbuf[128];//can have 128 params
    char** args = argsbuf;//point to first param
    //get params
    for(int i=1;i<argc;i++){
        *args = argv[i];
        args++;
    }
    //pa point to [] param
    char** pa = args;//pa == &first_kongbai_char*

    while(read(0,p,1)!=0){//get a byte from dev0 and saved to p  
        if(*p==' '||*p == '\n'){
            *p = '\0';

            *(pa++) = last_p;//pa point to the begin of this param
            last_p = p+1;

            if(*p == '\n'){
                *pa = 0;//exec要求参数数组以NULL结束
                run(argv[1],argsbuf);
                pa = args;
            }
        }
        p++;
    }
    //the last line don't have \n ,so need to sspecially solved
    if(pa != args){
        *p = '\0';
        *(pa++) = last_p;
        *pa = 0;

        run(argv[1],argsbuf);
    }

    while(wait(0) != -1){};

    exit(0);

}