#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

// 单向通信：数据只能从 写端（fd[1]） 流向 读端（fd[0]）。

int main(int argc, char** argv){
    int pFatherToSun[2];
    int pSunToFather[2];
    //create pipe
    pipe(pFatherToSun);
    pipe(pSunToFather);
    //fork:在父进程中：返回子进程的进程 ID（PID，正整数）。
    //     在子进程中：返回 0。
    int pid = fork();
    if(pid != 0){//father process
        write(pFatherToSun[1],"a",1);
        char buf;
        read(pSunToFather[0],&buf,1);
        int fatherpid = getpid();
        printf("%d: received pong\n",fatherpid);
        //wait(statue)  阻塞当前进程（即父进程），直到其某个子进程终止 
        wait(0);//通过 status 参数获取子进程的退出状态（若 status 不为 NULL or 0）
    }else{//child process
        char buf;
        read(pFatherToSun[0],&buf,1);
        int childpid = getpid();
        printf("%d: received ping\n",childpid);
        write(pSunToFather[1],&buf,1);
    }
    
    exit(0);
}